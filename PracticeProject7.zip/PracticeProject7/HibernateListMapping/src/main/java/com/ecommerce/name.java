package com.ecommerce;
package="com.ecommerce">
    <class name="Finance" table="finance">
        <id name="FINANCEID" type="long" column="ID">
            <generator class="identity"/>
        </id>
        <property name="name" type="string" column="NAME"/>
        <property name="ftype" type="string" column="FTYPE"/>
    </class>
</hibernate-mapping>
